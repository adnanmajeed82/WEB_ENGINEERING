

<DOCTYPE html>
	<html>
	<head>
		<title> Multiplication Table </title>
	</head>

	<body>
		<h1> table 1 to 20 </h1>
		<table border="1" cellpadding="5" cellspacing="0">
			<?php

			for ($i=1; $i<=20; $i++){
				echo "<tr>";
				for ($j=1; $j<=20; $j++){
					echo "<td>" .($i * $j) . "</td>";
				}
				echo "</tr>";
			}
		?>
	</table>
</body>
</html>