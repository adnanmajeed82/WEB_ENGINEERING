<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Input in PHP</title>
</head>
<body>
    <h1>Simple User Input Program</h1>
    <form method="POST" action="">
        <label for="name">Enter your name:</label>
        <input type="text" id="name" name="name" required>
        <br><br>
        
        <label for="email">Enter your email:</label>
        <input type="email" id="email" name="email" required>
        <br><br>

        <label for="message">Your message:</label>
        <textarea id="message" name="message" rows="4" cols="50" required></textarea>
        <br><br>
        
        <button type="submit">Submit</button>
    </form>

    <hr>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get user input
        $name = htmlspecialchars($_POST["name"]);
        $email = htmlspecialchars($_POST["email"]);
        $message = htmlspecialchars($_POST["message"]);

        // Display the input
        echo "<h2>User Input:</h2>";
        echo "<p><strong>Name:</strong> $name</p>";
        echo "<p><strong>Email:</strong> $email</p>";
        echo "<p><strong>Message:</strong> $message</p>";
    }
    ?>
</body>
</html>
