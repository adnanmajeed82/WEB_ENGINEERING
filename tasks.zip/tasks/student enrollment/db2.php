<?php

date_default_timezone_set("UTC");

$name = "Adnan";
$greeting = (date("H") < 12) ? "Good Morning" : "Good Evening";

$sum = 15 + 35;

// Correcting the date format string and fixing concatenation
echo "$greeting, $name! Today is " . date("l, F j, Y") . ". The sum of 15 and 35 is $sum.";

?>
