<?php
$pdo = new PDO('mysql:host=localhost;dbname=student_db', 'root', ''); // Connect to database
$query = $pdo->query("SELECT * FROM students"); // Execute query
while ($row = $query->fetch()) { // Fetch results dynamically
    echo "Name: {$row['name']}, Age: {$row['age']}<br>";
    echo "email: {$row['email']}, course: {$row['course']}<br>"; // Display results
}
?>