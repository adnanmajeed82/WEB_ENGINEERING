

<?php

$price = 1000;
$discount = 10;

$saleprice = $price - ($price * $discount / 100);

echo "original price : $price <br> saleprice: $saleprice";



?>