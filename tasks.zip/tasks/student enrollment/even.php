<?php


function checkEvenOdd($number){
	if ($number % 2 == 0 ){
	echo "The number $number is Even";
	}
	else {
	echo "The number $number is odd";
	}
}

$number = 84;
checkEvenOdd($number);
?>