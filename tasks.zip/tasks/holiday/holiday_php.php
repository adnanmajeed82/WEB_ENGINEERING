<?php
session_start();

if (!isset($_SESSION['holidayPlans'])) {
    $_SESSION['holidayPlans'] = [];
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['addPlan'])) {
        $destination = htmlspecialchars($_POST['destination']);
        $startDate = htmlspecialchars($_POST['startDate']);
        $endDate = htmlspecialchars($_POST['endDate']);
        if ($destination && $startDate && $endDate) {
            $_SESSION['holidayPlans'][] = [
                'destination' => $destination,
                'startDate' => $startDate,
                'endDate' => $endDate
            ];
        }
    } elseif (isset($_POST['deletePlan'])) {
        $index = intval($_POST['deletePlan']);
        unset($_SESSION['holidayPlans'][$index]);
        $_SESSION['holidayPlans'] = array_values($_SESSION['holidayPlans']);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Holiday Plans</title>
</head>
<body>

    <h1>Holiday Plans</h1>

    <!-- Form to add a new holiday plan -->
    <form method="post">
        <label for="destination">Destination:</label>
        <input type="text" id="destination" name="destination" required><br>

        <label for="startDate">Start Date:</label>
        <input type="date" id="startDate" name="startDate" required><br>

        <label for="endDate">End Date:</label>
        <input type="date" id="endDate" name="endDate" required><br>

        <button type="submit" name="addPlan">Add Plan</button>
    </form>

    <h2>Your Holiday Plans</h2>
    <ul>
        <?php if (!empty($_SESSION['holidayPlans'])): ?>
            <?php foreach ($_SESSION['holidayPlans'] as $index => $plan): ?>
                <li>
                    <strong>Destination:</strong> <?= $plan['destination'] ?> |
                    <strong>Start Date:</strong> <?= $plan['startDate'] ?> |
                    <strong>End Date:</strong> <?= $plan['endDate'] ?>
                    
                    <form method="post" style="display:inline;">
                        <button type="submit" name="deletePlan" value="<?= $index ?>">Delete</button>
                    </form>
                </li>
            <?php endforeach; ?>
        <?php else: ?>
            <li>No holiday plans added yet</li>
        <?php endif; ?>
    </ul>

</body>
</html>
