<!DOCTYPE html>
<html>
<head> 
    <title>Arithmetic Operation</title>
</head>
<body>

    <h2>Arithmetic Operation</h2>
    <h3> write a program by using user input to calculate arithmetic operation </h3>
    <form method="post" action="">
        <label for="num1">Enter First Number: </label>
        <input type="text" id="num1" name="num1" required><br><br>

        <label for="num2">Enter Second Number: </label>
        <input type="text" id="num2" name="num2" required><br><br>

        <label for="operation">Select Operation: </label>
        <select id="operation" name="operation" required>
            <option value="+">Addition (+)</option>
            <option value="-">Subtraction (-)</option>
            <option value="*">Multiplication (*)</option>
            <option value="/">Division (/)</option>
        </select><br><br>

        <input type="submit" value="Calculate">
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $num1 = $_POST['num1'];
        $num2 = $_POST['num2'];
        $operation = $_POST['operation'];

        if (is_numeric($num1) && is_numeric($num2)) {
            switch ($operation) {
                case '+':
                    $result = $num1 + $num2;
                    break;
                case '-':
                    $result = $num1 - $num2;
                    break;
                case '*':
                    $result = $num1 * $num2;
                    break;
                case '/':
                    $result = $num2 != 0 ? $num1 / $num2 : "Error: Division by zero";
                    break;
                default:
                    $result = "Error: Invalid operation";
            }
            echo "<h3>Result: $num1 $operation $num2 = $result</h3>";
        } else {
            echo "<h3>Error: Please enter valid numeric values</h3>";
        }
    }
    ?>
</body>
</html>
