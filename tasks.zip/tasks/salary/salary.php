<?php


function calculateSalary($basic_salary, $allownces, $deductions){
	
	$gross_salary = $basic_salary+$allownces;

	$net_salary=$gross_salary - $deductions;

	return [
        'gross_salary' => $gross_salary,
        'net_salary' => $net_salary

	];
}

$basic_salary = 60000;
$allownces= 150000;
$deductions=8000;

$salary = calculateSalary($basic_salary, $allownces, $deductions);

echo "Basic Salary: $" . number_format($basic_salary,2) . "<br>";
echo "allownces: $" . number_format($allownces,2) . "<br>";
echo "deductions: $" . number_format($deductions, 2) , "<br>";
echo "Gross Salary: $" . number_format($salary ['gross_salary'], 2) . "<br>";
echo "Net Salary: $" . number_format($salary['net_salary'] , 2) . "<br>";




?>