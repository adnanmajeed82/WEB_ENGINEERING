<?php
$num1 = isset($_GET['num1']) ? floatval($_GET['num1']) : 1;
$num2 = isset($_GET['num2']) ? floatval($_GET['num2']) : 2;
$op = $_GET['op'] ?? '+';

// Validate and perform the operation
switch ($op) {
    case '+':
        $result = $num1 + $num2;
        break;
    case '-':
        $result = $num1 - $num2;
        break;
    case '*':
        $result = $num1 * $num2;
        break;
    case '/':
        $result = ($num2 != 0) ? $num1 / $num2 : 'Error: Division by zero';
        break;
    default:
        $result = 'Error: Invalid operator';
        break;
}

echo "Result: $result";
?>
